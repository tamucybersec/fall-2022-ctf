from random import choices
from string import ascii_letters, digits
import pathlib
import os

charset = ascii_letters + digits

for i in range(4096):
    d = ''.join(choices(charset, k=4))
    f = ''.join(choices(charset, k=32))
    pathlib.Path(f"./{d}").mkdir(parents=True, exist_ok=True)
    with open(f'./{d}/{f}', 'wb') as oF:
        oF.write(os.urandom(4096))
